#' Construct Orthogonal Discrete Wavelet Transformation Matrix
#'
#' This function generates a transformation matrix for a wavelet packet based on a given
#' low-pass filter, matrix size, depth of transformation, and shift. The transformation matrix
#' can be used in wavelet-based data analysis and signal processing.
#'
#' @param h Numeric vector representing the low-pass filter.
#' @param N Integer specifying the size of the matrix. Must be a power of 2.
#' @param k0 Integer specifying the depth of the wavelet transformation. Should be between 1 and log2(N).
#' @param shift Integer for shifts in the wavelet transformation (default is 2).
#' @return A numeric matrix representing the wavelet packet transformation.
#' @examples
#' h <- c(0.5, 0.5) # Example low-pass filter
#' N <- 8           # Example size of the matrix (must be a power of 2)
#' k0 <- 3          # Depth of the wavelet transformation
#' WavPackMat(h, N, k0)
#' @export
WavPackMat <- function(h, N, k0, shift = 2) {
  # WavPackMat -- Transformation Matrix for Wavelet Packet

  J <- log2(N)

  # Check that N is a power of 2
  if (J != floor(J)) {
    stop("N has to be a power of 2.")
  }

  # Extend filters h and g by padding zeros up to length N
  h <- c(as.vector(h), rep(0, N - length(h)))
  g <- rev(Conj(h) * (-1)^(1:length(h)))

  # Construct the wavelet packet transformation matrix
  WP <- matrix(nrow = 0, ncol = N)
  for (k in 1:k0) {
    subW <- getsubW(k, h, g, J, N)
    WP <- rbind(WP, subW)
  }
  WP <- sqrt(1 / k0) * WP

  return(WP)
}

# Internal function to construct a sub-matrix for a given level of wavelet packet transformation
getsubW <- function(jstep, h, g, J, N) {
  subW <- diag(2^(J - jstep))
  for (k in jstep:1) {
    hgmat <- getHGmat(k, h, g, J, N)
    subW <- rbind(subW %*% hgmat$hmat, subW %*% hgmat$gmat)
  }
  return(subW)
}

# Internal function to construct H and G matrices based on the wavelet filter and transformation level
getHGmat <- function(k, h, g, J, N) {
  ubJk <- 2^(J - k)
  ubJk1 <- 2^(J - k + 1)
  shift <- 2  # Default shift value

  hmat <- matrix(0, nrow = ubJk1, ncol = ubJk)
  gmat <- matrix(0, nrow = ubJk1, ncol = ubJk)

  for (jj in 1:ubJk) {
    for (ii in 1:ubJk1) {
      modulus <- (N + ii - 2 * jj + shift) %% ubJk1
      modulus <- modulus + (modulus == 0) * ubJk1
      hmat[ii, jj] <- h[modulus]
      gmat[ii, jj] <- g[modulus]
    }
  }

  return(list(hmat = t(hmat), gmat = t(gmat)))
}
